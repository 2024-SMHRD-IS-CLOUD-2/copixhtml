package com.smhrd3.resultmodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@AllArgsConstructor 
@NoArgsConstructor 

public class resultDTO {
	
	
	
	private String turtle_N;
	private String diag_AT;
	private String angle;
	private String score;
}
